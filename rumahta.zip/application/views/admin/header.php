<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>

	<title>RUMAHTA.COM | Web Jual Beli Properti Sulawesi Selatan</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<meta name="keywords" content="properti sulawesi selatan, Makassar, Iklan Properti, rumahta, jual beli properti, pasang iklan gratis, pasang iklan properti gratis" />
	<meta name="Title" content="web development jakarta" />
	<meta name="description" content="rumahta.com adalah website jual, beli, sewa properti di Sulawesi Selatan. Pasang Iklan properti gratis di rumahta.com"/>
	<meta name="copyright" content="&copy; 2012 Binary Project"/>
	<meta name="classification" content="General"/>
	<meta name="rating" content="General"/>
	<meta name="distribution" content="Global"/>
	<meta name="robots" content="index, follow" />
	<meta name="googlebot" content="index,follow" />
	<meta name="msnbot" content="index,follow" />
	<meta name="author" content="www.binary-project.com"/>

	<!-- Attach CSS File -->
	<link rel="stylesheet" href="<?php echo base_url();?>file/css/style.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo base_url();?>file/css/bootstrap.css" />
	
	<!-- Attach JS File -->
	<script src="<?php echo base_url();?>file/js/jquery-1.7.1.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>file/js/jquery-ui.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>file/js/bootstrap.js" type="text/javascript"></script>
	
</head>
<body>
	<!--<div id="header">
		<div id="logo"></div><!--
		<div id="loginform">
			<p>
				Belum punya akun ? <?php //echo anchor("home/signup","Daftar Sekarang");?> | <a href="#">Lupa Password</a>
			</p>
			<?php //echo form_open("home/validate_login"); ?>
				<img src="<?php //echo base_url();?>file/img/icon_username.png" />
				<input type="text" class="span2 login" name="username" id="username" placeholder="username" />
				&nbsp;&nbsp;
				<img src="<?php// echo base_url();?>file/img/icon_password.png" />
				<input type="password" class="span2 login" name="password" id="password" placeholder="password" />
				<input type="submit" class="btn btn-inverse" value="&nbsp;&nbsp;Login&nbsp;&nbsp;" />
			<?php// echo form_close(); ?>
		</div>-->
	<!--</div>-->
	
	<div id="admin_container">