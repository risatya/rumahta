
					<div id="inside_main_wrapper">
						<?php if($message != null){?>
							<div class='alert alert-info'>
								<?php echo $message; ?>
							</div>
						<?php } ?>
						<fieldset>
							<legend>MAAF ! </legend>
							<div class='alert alert-important'>
								Listing tidak ditemukan.
							</div>
						</fieldset>
					</div>