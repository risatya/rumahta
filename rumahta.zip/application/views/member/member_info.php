		<div id="main_wrapper">
			<!--<div id="search_title">
				<span>Pencarian Cepat</span>
			</div>-->
			
			<!--<div class="well" style="padding-bottom:35px">
				<div style="width:47%;float:left;margin-bottom:10px;">
					<?php// foreach($info_paket as $item): ?>
						<i class="icon icon-th-large"></i> Paket Listing : <span class="label label-success"><?php //echo $item->nama_paket; ?></span><br/>
						<i class="icon icon-tasks"></i> Quota untuk pasang Listing : <span class="label label-success"><?php //echo $item->quota; ?> Listing</span>
					<?php //endforeach; ?>
				</div>
				<div style="width:53%;float:right;">
					<div class="btn-group">
					  <?php //echo anchor("member_listing/pilih_paket","<i class='icon icon-tag'></i> Pasang Listing",array("class"=>"btn")); ?>
					  <?php //echo anchor("#","<i class='icon icon-arrow-up'></i> Upgrade Paket Listing",array("class"=>"btn")); ?>
					</div>
				</div>
			</div>-->
			<!--<div class="btn-group" style="float : right;">
			  <?php //echo anchor("member_listing/pilih_paket","<i class='icon icon-tag'></i> Pasang Listing",array("class"=>"btn")); ?>
			  <?php //echo anchor("#","<i class='icon icon-arrow-up'></i> Upgrade Paket Listing",array("class"=>"btn")); ?>
			</div>-->
		</div>