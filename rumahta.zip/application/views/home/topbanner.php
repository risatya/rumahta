		<div id="content_wrapper">
			<div id="left_wrapper">
				<div id="top_banner"><?php echo anchor(($banner['top1']['url'] == null ? "#" : "http://".$banner['top1']['url']),"<img id='top_banner' src='".base_url()."file/img/banner/".$banner['top1']['pic']."'/>"); ?></div>
				