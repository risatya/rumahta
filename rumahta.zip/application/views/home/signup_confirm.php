				<div id="main_wrapper">
					<div id="main_title">
						<span>Pendaftaran Member</span>
					</div>
					<div id="main_line"></div>
					<div id="signup_form">
						<div class='alert alert-info'>
							Terima Kasih! Kami telah mengirimkan link verifikasi ke email anda.
							silakan cek email anda untuk mengaktifkan akun member.
							<br/><br/>
							catatan : Jika anda tidak menemukan email follow up dari kami di inbox email anda kemungkinan masuk ke halaman spam atau tunggu maks. 10 menit atau kemungkinan anda salah memasukkan alamat email.
							<br/>
							silakan hubungi customr service kami pada halaman kontak.
						</div>
					</div>