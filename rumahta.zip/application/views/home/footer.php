		</div>
	</div>
	<div id="footer">
		<div id="footer_wrapper">
			<div id="footer_col_1">
				<h6 class="foot_title">Dijual</h6>
				<?php echo anchor("page/category/1","Rumah Dijual"); ?><br/>
				<?php echo anchor("page/category/2","Apartemen Dijual"); ?><br/>
				<?php echo anchor("page/category/3","Tanah Dijual"); ?><br/>
				<?php echo anchor("page/category/4","Ruko/Rukan Dijual"); ?><br/>
				<?php echo anchor("page/category/5","Kios Dijual"); ?><br/>
				<?php echo anchor("page/category/6","Gudang/Pabrik Dijual"); ?>
			</div>
			<div id="footer_col_2">
				<h6 class="foot_title">Disewakan</h6>
				<?php echo anchor("page/category/9","Rumah Disewakan"); ?><br/>
				<?php echo anchor("page/category/10","Apartemen Disewakan"); ?><br/>
				<?php echo anchor("page/category/11","Tanah Disewakan"); ?><br/>
				<?php echo anchor("page/category/12","Ruko/Rukan Disewakan"); ?><br/>
				<?php echo anchor("page/category/13","Kios Disewakan"); ?><br/>
				<?php echo anchor("page/category/14","Gudang/Pabrik Disewakan"); ?>
			</div>
			<div id="footer_col_3">
				<h6 class="foot_title">Iklan</h6>
				<?php echo anchor("home/index","Iklan Terbaru"); ?><br/>
				<?php echo anchor("page/page_detail/15/pasang-iklan","Pasang Iklan"); ?><br/>
				<?php echo anchor("page/page_detail/7/faq","FAQ"); ?><br/>
				<?php echo anchor("page/page_detail/6/syarat-dan-ketentuan","Syarat dan ketentuan"); ?><br/>
				<?php echo anchor("page/page_detail/5/spesifikasi-iklan","Spesifikasi Iklan"); ?>
			</div>
			<div id="footer_col_4">
				<h6 class="foot_title">Tentang Rumahta.com</h6>
				<?php echo anchor("page/page_detail/19/tentang-rumahta","Tentang Rumahta.com"); ?><br/>
				<a href="#">Testimonial</a><br/>
				<a href="#">Berita terbaru</a><br/>
				<?php echo anchor("page/page_detail/3/kontak","Kontak kami"); ?><br/>
				Copyright &copy; 2012 | Rumahta.com
			</div>
		</div>
	</div>
</body>